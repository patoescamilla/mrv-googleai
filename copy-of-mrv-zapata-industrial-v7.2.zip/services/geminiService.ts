
import { GoogleGenAI } from "@google/genai";
import { db } from "../db";

export async function getAIStrategyAnalysis() {
  // Always initialize GoogleGenAI with a named parameter using process.env.API_KEY directly.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Fetch current stats for context
  const transactions = await db.transactions.toArray();
  const inventory = await db.inventory.toArray();
  const cash = await db.cashLogs.toArray();

  const context = {
    transactionSummary: transactions.slice(-20),
    inventoryLevels: inventory,
    recentCashFlow: cash.slice(-10),
    timestamp: new Date().toISOString()
  };

  const prompt = `
    Actúa como un Director de Estrategia Industrial de alto nivel. 
    Analiza los siguientes datos de operación de MRV ZAPATA INDUSTRIAL:
    ${JSON.stringify(context)}

    Proporciona un informe estructurado en Markdown que incluya:
    1. Análisis de Rentabilidad Reciente.
    2. Identificación de Cuellos de Botella o anomalías.
    3. Recomendaciones estratégicas de compra/venta para maximizar margen.
    4. Proyección de flujo de caja.

    Mantén un tono profesional, directo y técnico. Usa términos industriales.
  `;

  try {
    // Generate content using the recommended Gemini 3 Pro model for complex reasoning tasks.
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 4000 }
      }
    });

    // Access the text property directly (not a method).
    return response.text || "No se pudo generar el análisis en este momento.";
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return "Error al conectar con la IA Estratégica. Verifique su conexión.";
  }
}
