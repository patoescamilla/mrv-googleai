
import React, { useState, useEffect } from 'react';
import { db } from '../db';
import { Person } from '../types';
import { ShieldCheck, Delete } from 'lucide-react';

interface LoginProps {
  onLogin: (user: Person) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleKeypad = (val: string) => {
    if (pin.length < 4) setPin(prev => prev + val);
  };

  const handleClear = () => setPin('');
  const handleDelete = () => setPin(prev => prev.slice(0, -1));

  useEffect(() => {
    if (pin.length === 4) {
      const checkPin = async () => {
        const user = await db.people.where('pin').equals(pin).first();
        if (user) {
          onLogin(user);
        } else {
          setError(true);
          setTimeout(() => {
            setError(false);
            setPin('');
          }, 1000);
        }
      };
      checkPin();
    }
  }, [pin, onLogin]);

  return (
    <div className="min-h-screen bg-industrial-black flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-industrial-dark border border-industrial-gray rounded-2xl p-8 space-y-8 shadow-2xl">
        <div className="text-center space-y-2">
          <div className="inline-flex p-4 rounded-full bg-industrial-lime/10 border border-industrial-lime/20 mb-4">
            <ShieldCheck className="text-industrial-lime" size={40} />
          </div>
          <h1 className="text-2xl font-bold tracking-tighter">ZAPATA INDUSTRIAL v7.2</h1>
          <p className="text-gray-500 font-mono text-xs uppercase tracking-[0.2em]">Acceso Restringido - Operador</p>
        </div>

        <div className="space-y-6">
          <div className="flex justify-center gap-4">
            {[...Array(4)].map((_, i) => (
              <div 
                key={i} 
                className={`w-4 h-4 rounded-full border-2 transition-all duration-300 ${
                  error ? 'bg-red-500 border-red-500 scale-110' : 
                  pin.length > i ? 'bg-industrial-lime border-industrial-lime' : 'border-gray-800'
                }`}
              />
            ))}
          </div>

          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
              <button
                key={num}
                onClick={() => handleKeypad(num.toString())}
                className="h-16 rounded-xl bg-industrial-black border border-industrial-gray text-2xl font-bold hover:border-industrial-lime hover:bg-industrial-lime/5 transition-all active:scale-95"
              >
                {num}
              </button>
            ))}
            <button onClick={handleClear} className="h-16 rounded-xl bg-industrial-black border border-industrial-gray text-xs font-bold uppercase text-gray-500 hover:text-red-500 hover:border-red-500 transition-all">Clear</button>
            <button onClick={() => handleKeypad('0')} className="h-16 rounded-xl bg-industrial-black border border-industrial-gray text-2xl font-bold hover:border-industrial-lime transition-all">0</button>
            <button onClick={handleDelete} className="h-16 rounded-xl bg-industrial-black border border-industrial-gray flex items-center justify-center text-gray-500 hover:text-white transition-all"><Delete size={24} /></button>
          </div>
        </div>
        
        <p className="text-center text-[10px] text-gray-700 font-mono uppercase tracking-widest">
          Sincronización Global de Llaves: Activa
        </p>
      </div>
    </div>
  );
};

export default Login;
