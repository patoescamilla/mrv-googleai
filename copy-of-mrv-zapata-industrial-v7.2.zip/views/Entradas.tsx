
import React, { useState, useEffect } from 'react';
import { db } from '../db';
import { InventoryItem, Person, TransactionType } from '../types';
import { Plus, Scale, Save } from 'lucide-react';

const Entradas: React.FC = () => {
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [providers, setProviders] = useState<Person[]>([]);
  const [selectedItem, setSelectedItem] = useState<string>('');
  const [selectedProvider, setSelectedProvider] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      setItems(await db.inventory.toArray());
      setProviders(await db.people.where('role').equals('PROVEEDOR').toArray());
    };
    loadData();
  }, []);

  const handleSave = async () => {
    if (!selectedItem || !selectedProvider || !weight) return;
    setIsSaving(true);
    
    try {
      const item = items.find(i => i.id === parseInt(selectedItem));
      const provider = providers.find(p => p.id === parseInt(selectedProvider));

      if (item && provider) {
        await db.transactions.add({
          type: TransactionType.ENTRADA,
          itemId: item.id!,
          itemName: item.name,
          weight: parseFloat(weight),
          total: item.pricePerUnit * parseFloat(weight),
          personId: provider.id!,
          personName: provider.name,
          timestamp: Date.now(),
          synced: false
        });
        setWeight('');
        alert('Transacción guardada correctamente.');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto h-full overflow-y-auto">
      <header className="mb-8 border-b border-industrial-gray pb-4">
        <h2 className="text-2xl font-bold flex items-center gap-3">
          <Scale className="text-industrial-lime" />
          MÓDULO DE PESAJE: ENTRADA
        </h2>
        <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Recepción de Materiales v7.2</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Proveedor / Origen</label>
            <select 
              value={selectedProvider} 
              onChange={(e) => setSelectedProvider(e.target.value)}
              className="w-full bg-industrial-dark border border-industrial-gray rounded-lg p-3 text-white focus:border-industrial-lime outline-none transition-all"
            >
              <option value="">Seleccionar Proveedor</option>
              {providers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Material</label>
            <select 
              value={selectedItem} 
              onChange={(e) => setSelectedItem(e.target.value)}
              className="w-full bg-industrial-dark border border-industrial-gray rounded-lg p-3 text-white focus:border-industrial-lime outline-none transition-all"
            >
              <option value="">Seleccionar Producto</option>
              {items.map(i => <option key={i.id} value={i.id}>{i.name} (${i.pricePerUnit}/kg)</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Peso Bruto (KG)</label>
            <div className="relative">
              <input 
                type="number" 
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder="0.00"
                className="w-full bg-industrial-dark border border-industrial-gray rounded-lg p-4 text-3xl font-mono text-industrial-lime placeholder:text-gray-800 outline-none focus:border-industrial-lime transition-all"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-600 font-bold">KG</span>
            </div>
          </div>

          <button 
            onClick={handleSave}
            disabled={isSaving || !weight}
            className="w-full bg-industrial-lime hover:bg-industrial-lime/90 disabled:opacity-50 text-black font-bold py-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-industrial-lime/10"
          >
            <Save size={20} />
            {isSaving ? 'PROCESANDO...' : 'REGISTRAR PESAJE'}
          </button>
        </div>

        <div className="bg-industrial-dark border border-industrial-gray rounded-xl p-6 flex flex-col justify-center items-center text-center space-y-4">
          <div className="w-24 h-24 rounded-full border-2 border-industrial-gray flex items-center justify-center text-gray-700">
            <Scale size={48} />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-gray-400">LECTURA DIGITAL ASISTIDA</h3>
            <p className="text-xs text-gray-600 px-8">Asegúrese de que la báscula esté en ceros antes de cada operación.</p>
          </div>
          <div className="w-full pt-6 border-t border-industrial-gray">
             <div className="flex justify-between text-[10px] font-mono mb-2">
               <span className="text-gray-500">RESUMEN DE CARGA</span>
               <span className="text-industrial-lime">ESTADO: OK</span>
             </div>
             <div className="bg-industrial-black p-4 rounded-lg border border-industrial-gray">
                <div className="flex justify-between items-center text-sm font-mono">
                  <span className="text-gray-500">Subtotal:</span>
                  <span className="text-white">$ {((items.find(i => i.id === parseInt(selectedItem))?.pricePerUnit || 0) * (parseFloat(weight) || 0)).toFixed(2)}</span>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Entradas;
