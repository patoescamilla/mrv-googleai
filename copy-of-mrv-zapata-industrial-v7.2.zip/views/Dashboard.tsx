
import React, { useState, useEffect } from 'react';
import { db } from '../db';
import { Transaction, TransactionType } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Activity, Package, TrendingUp, TrendingDown } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState({ entrances: 0, exits: 0, totalWeight: 0 });

  useEffect(() => {
    const fetchData = async () => {
      const data = await db.transactions.orderBy('timestamp').reverse().limit(50).toArray();
      setTransactions(data);

      const all = await db.transactions.toArray();
      const inW = all.filter(t => t.type === TransactionType.ENTRADA).reduce((acc, t) => acc + t.weight, 0);
      const outW = all.filter(t => t.type === TransactionType.SALIDA).reduce((acc, t) => acc + t.weight, 0);
      setStats({
        entrances: all.filter(t => t.type === TransactionType.ENTRADA).length,
        exits: all.filter(t => t.type === TransactionType.SALIDA).length,
        totalWeight: inW - outW
      });
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const chartData = [
    { name: 'Entradas', value: stats.entrances },
    { name: 'Salidas', value: stats.exits },
  ];

  return (
    <div className="p-8 space-y-8 h-full overflow-y-auto">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">DASHBOARD ESTRATÉGICO</h2>
          <p className="text-gray-500 font-mono text-sm">MONITORIZACIÓN DE PLANTA EN TIEMPO REAL</p>
        </div>
        <div className="text-right">
          <p className="text-industrial-lime font-mono text-xs">ESTADO DE RED: OMNI-SYNC ACTIVO</p>
          <p className="text-gray-600 text-[10px]">ID: NO_LINKED_PRO_V7</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard 
          icon={<TrendingUp className="text-industrial-lime" />} 
          title="PESAJE ENTRADA" 
          value={stats.entrances} 
          unit="OPS" 
        />
        <StatCard 
          icon={<TrendingDown className="text-orange-500" />} 
          title="PESAJE SALIDA" 
          value={stats.exits} 
          unit="OPS" 
        />
        <StatCard 
          icon={<Package className="text-blue-400" />} 
          title="STOCK ESTIMADO" 
          value={stats.totalWeight.toFixed(2)} 
          unit="KG" 
        />
        <StatCard 
          icon={<Activity className="text-purple-400" />} 
          title="SYNC DELTA" 
          value="10" 
          unit="SEG" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-industrial-dark border border-industrial-gray rounded-xl p-6 glow-lime">
          <h3 className="text-sm font-bold text-gray-400 mb-6 uppercase tracking-widest flex items-center gap-2">
            <div className="w-1 h-4 bg-industrial-lime"></div>
            Flujo de Operaciones (Últimas 50)
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis dataKey="name" stroke="#555" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#555" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '8px' }}
                  itemStyle={{ color: '#8cc63f' }}
                />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#8cc63f' : '#f97316'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-industrial-dark border border-industrial-gray rounded-xl p-6 overflow-hidden flex flex-col">
          <h3 className="text-sm font-bold text-gray-400 mb-4 uppercase tracking-widest flex items-center gap-2">
            <div className="w-1 h-4 bg-industrial-lime"></div>
            Log de Transacciones
          </h3>
          <div className="flex-1 space-y-3 overflow-y-auto font-mono text-xs">
            {transactions.map((t) => (
              <div key={t.id} className="p-3 bg-industrial-black border border-industrial-gray/50 rounded flex justify-between items-center group hover:border-industrial-lime/30 transition-colors">
                <div>
                  <span className={t.type === TransactionType.ENTRADA ? 'text-industrial-lime' : 'text-orange-500'}>
                    [{t.type}]
                  </span>
                  <span className="text-gray-300 ml-2">{t.itemName}</span>
                </div>
                <div className="text-right">
                  <p className="text-white font-bold">{t.weight} kg</p>
                  <p className="text-gray-600 text-[10px]">{new Date(t.timestamp).toLocaleTimeString()}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode, title: string, value: string | number, unit: string }> = ({ icon, title, value, unit }) => (
  <div className="bg-industrial-dark border border-industrial-gray p-6 rounded-xl hover:bg-industrial-gray/50 transition-all cursor-default">
    <div className="flex justify-between items-start mb-4">
      <div className="p-2 bg-industrial-black rounded-lg border border-industrial-gray">{icon}</div>
      <span className="text-[10px] text-gray-600 font-mono font-bold tracking-widest">{unit}</span>
    </div>
    <h4 className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-1">{title}</h4>
    <p className="text-2xl font-bold font-mono text-industrial-text">{value}</p>
  </div>
);

export default Dashboard;
