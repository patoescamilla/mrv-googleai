
import React, { useState } from 'react';
import { getAIStrategyAnalysis } from '../services/geminiService';
import { BrainCircuit, Sparkles, RefreshCw, AlertCircle } from 'lucide-react';

const AIStrategy: React.FC = () => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    setIsLoading(true);
    const result = await getAIStrategyAnalysis();
    setAnalysis(result);
    setIsLoading(false);
  };

  return (
    <div className="p-8 h-full flex flex-col overflow-hidden">
      <header className="mb-8 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <BrainCircuit className="text-industrial-lime" />
            AI STRATEGY ENGINE
          </h2>
          <p className="text-gray-500 font-mono text-xs uppercase tracking-widest mt-1">Basado en Gemini 3 Pro Preview</p>
        </div>
        <button 
          onClick={handleGenerate}
          disabled={isLoading}
          className="bg-industrial-lime text-black px-6 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-industrial-lime/90 transition-all disabled:opacity-50"
        >
          {isLoading ? <RefreshCw className="animate-spin" size={18} /> : <Sparkles size={18} />}
          {analysis ? 'RE-ANALIZAR' : 'GENERAR ESTRATEGIA'}
        </button>
      </header>

      <div className="flex-1 bg-industrial-dark border border-industrial-gray rounded-xl p-8 overflow-y-auto relative glow-lime">
        {!analysis && !isLoading ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-6 max-w-md mx-auto">
            <div className="p-6 rounded-full bg-industrial-lime/5 border border-industrial-lime/20">
              <BrainCircuit size={64} className="text-industrial-lime/50" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Sin Análisis Estratégico</h3>
              <p className="text-gray-500 text-sm">
                Pulsa el botón superior para enviar los datos de inventario y transacciones al motor de IA de Gemini 3 Pro.
              </p>
            </div>
          </div>
        ) : isLoading ? (
          <div className="h-full flex flex-col items-center justify-center space-y-4">
            <div className="w-16 h-16 border-4 border-industrial-lime border-t-transparent rounded-full animate-spin"></div>
            <p className="font-mono text-industrial-lime animate-pulse">PROCESANDO BIG DATA INDUSTRIAL...</p>
            <p className="text-gray-600 text-xs uppercase tracking-[0.2em]">Consultando Modelos de Razonamiento Gemini 3</p>
          </div>
        ) : (
          <div className="prose prose-invert prose-lime max-w-none">
            <div className="flex items-center gap-2 text-[10px] font-mono text-industrial-lime mb-6 p-2 bg-industrial-lime/5 border border-industrial-lime/20 rounded inline-flex">
              <AlertCircle size={14} />
              INFORME CONFIDENCIAL GENERADO POR IA
            </div>
            <div className="whitespace-pre-wrap font-sans text-gray-300 leading-relaxed">
              {analysis}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIStrategy;
